exports.id = 308;
exports.ids = [308];
exports.modules = {

/***/ 6293:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(701);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9886);
/* harmony import */ var _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var _material_ui_icons_Facebook__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2089);
/* harmony import */ var _material_ui_icons_Facebook__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Facebook__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_icons_Twitter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4233);
/* harmony import */ var _material_ui_icons_Twitter__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Twitter__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_icons_YouTube__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7764);
/* harmony import */ var _material_ui_icons_YouTube__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_YouTube__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _material_ui_icons_Instagram__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8162);
/* harmony import */ var _material_ui_icons_Instagram__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Instagram__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);











const FooterV1 = () => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
    className: _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_8__.main,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
      className: `${_styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_8__.section} ${_styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_8__.section1}`,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h3", {
        className: _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_8__.label,
        children: "Contact Us"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("p", {
        className: _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_8__.text,
        children: "+0917 183 5762"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("p", {
        className: _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_8__.text,
        children: "402 4th Flr, Galleria Corporate Center, EDSA Corner, Ortigas Ave, Quezon City, 1110 Metro Manila"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("p", {
        className: _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_8__.text,
        children: "bagongbayan@gmail.com"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
        className: _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_8__.socialMediaContainer,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
          className: _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_8__.socialBox,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx((_material_ui_icons_Facebook__WEBPACK_IMPORTED_MODULE_3___default()), {
            style: {
              color: "#fff",
              fontSize: '30px'
            }
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
          className: _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_8__.socialBox,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx((_material_ui_icons_Instagram__WEBPACK_IMPORTED_MODULE_6___default()), {
            style: {
              color: "#fff",
              fontSize: '30px'
            }
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
          className: _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_8__.socialBox,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx((_material_ui_icons_Twitter__WEBPACK_IMPORTED_MODULE_4___default()), {
            style: {
              color: "#fff",
              fontSize: '30px'
            }
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
          className: _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_8__.socialBox,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx((_material_ui_icons_YouTube__WEBPACK_IMPORTED_MODULE_5___default()), {
            style: {
              color: "#fff",
              fontSize: '30px'
            }
          })
        })]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h4", {
        className: _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_8__.buttonFont,
        children: "DONATE"
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
      className: `${_styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_8__.section} ${_styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_8__.section2}`,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("img", {
        src: "/Logo/LogoWhite.png",
        className: _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_8__.image
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
      className: `${_styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_8__.section} ${_styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_8__.section3}`,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("h3", {
        className: _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_8__.label,
        children: "Sign up for updates"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("p", {
        className: _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_8__.text,
        children: "Coming Soon"
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FooterV1);

/***/ }),

/***/ 9109:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8211);
/* harmony import */ var _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var _material_ui_icons_Close__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8777);
/* harmony import */ var _material_ui_icons_Close__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Close__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);







const NavigationV1 = ({
  pos,
  open,
  setOpen,
  header
}) => {
  const [drawer, setDrawer] = react__WEBPACK_IMPORTED_MODULE_0__.useState(null);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
    className: open ? _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.off : _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.main,
    children: [header && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
      className: _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.navbar,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
        className: _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.navbar1,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
          className: _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.tinylogoToken,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("img", {
            src: '/Logo/logowhite.png',
            alt: "Logo",
            className: _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.logoToken
          })
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
        className: _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.navbar3,
        onClick: () => {
          setOpen(!open);
        },
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx((_material_ui_icons_Close__WEBPACK_IMPORTED_MODULE_2___default()), {
          style: {
            color: "#fff",
            fontSize: '40px'
          }
        })
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
      className: _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.navbar2,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
        className: _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.buttonBox,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
          href: "/join",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h4", {
            className: _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.h4animate,
            children: "Join The Advocacy"
          })
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
        className: _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.buttonBox,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
          href: "/join",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h4", {
            className: _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.h4animate,
            children: "Get Involved"
          })
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
        className: _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.buttonBox,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
          href: "/info/about",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h4", {
            className: _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.h4animate,
            children: "About Ernie"
          })
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
        className: _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.buttonBox,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
          href: "/info/about",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h4", {
            className: _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.h4animate,
            children: "Priorities"
          })
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
        className: _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.buttonBox,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
          href: "/info/about",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h4", {
            className: _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.h4animate,
            children: "News"
          })
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
        className: _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.buttonBox,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
          href: "/info/about",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h4", {
            className: _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.h4animate,
            children: "Articles"
          })
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
        className: _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.specialbuttonBox,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__.default, {
          href: "/info/about",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h4", {
            className: _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.specialh4animate,
            children: "Donate"
          })
        })
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
      className: _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.rightsBox,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
        className: _styles_navigation_navigationv1_module_css__WEBPACK_IMPORTED_MODULE_4__.rightsText,
        children: "2021 \xA9 ErnieAbella.COM | All rights reserved"
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavigationV1);

/***/ }),

/***/ 9886:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "footerv1_main__3leWD",
	"title": "footerv1_title__335nt",
	"buttonContainer": "footerv1_buttonContainer__2DNoU",
	"section": "footerv1_section__1E_Z5",
	"section1": "footerv1_section1__3uqKa",
	"label": "footerv1_label__2V5Ac",
	"text": "footerv1_text__3se5g",
	"socialMediaContainer": "footerv1_socialMediaContainer__2r940",
	"socialBox": "footerv1_socialBox__2c9st",
	"section2": "footerv1_section2__18SMc",
	"image": "footerv1_image__1rWtf",
	"section3": "footerv1_section3__288qI",
	"buttonFont": "footerv1_buttonFont__21I_r",
	"foooterv2": "footerv1_foooterv2__17x3V",
	"copywrite": "footerv1_copywrite__2BLc5"
};


/***/ }),

/***/ 8211:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "navigationv1_main__2_31O",
	"bodyanimate": "navigationv1_bodyanimate__FsI_y",
	"off": "navigationv1_off__3Jj8y",
	"navbar": "navigationv1_navbar__35mfi",
	"tinylogoToken": "navigationv1_tinylogoToken__2INrZ",
	"logoToken": "navigationv1_logoToken__6OtX4",
	"navbar1": "navigationv1_navbar1__2ywE3",
	"navbar3": "navigationv1_navbar3__3SQVg",
	"navbar2": "navigationv1_navbar2__1YeF6",
	"buttonBox": "navigationv1_buttonBox__1DhGg",
	"h4animate": "navigationv1_h4animate__3Q-A6",
	"specialbuttonBox": "navigationv1_specialbuttonBox__2wi9e",
	"specialh4animate": "navigationv1_specialh4animate__2WqFw",
	"rightsBox": "navigationv1_rightsBox__2ojYZ",
	"rightsText": "navigationv1_rightsText__tP53S",
	"icon": "navigationv1_icon__3Reu7",
	"drawerButton": "navigationv1_drawerButton__2EAYg",
	"svgUp": "navigationv1_svgUp__2F9kV",
	"svgDown": "navigationv1_svgDown__3cgYZ",
	"drawerOpen": "navigationv1_drawerOpen__WRTRP",
	"drawerClose": "navigationv1_drawerClose__2v5MU",
	"drawerLink": "navigationv1_drawerLink__2ACOe"
};


/***/ }),

/***/ 2431:
/***/ (() => {

/* (ignored) */

/***/ })

};
;