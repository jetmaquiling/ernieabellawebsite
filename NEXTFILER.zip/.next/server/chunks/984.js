exports.id = 984;
exports.ids = [984];
exports.modules = {

/***/ 5984:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ HeadV2)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(701);
// EXTERNAL MODULE: ./styles/navigation/headv2.module.css
var headv2_module = __webpack_require__(1011);
// EXTERNAL MODULE: ./components/navigation/navigationv1.js
var navigationv1 = __webpack_require__(9109);
// EXTERNAL MODULE: ./styles/navigation/headv1.module.css
var headv1_module = __webpack_require__(1732);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "@material-ui/icons/Menu"
var Menu_ = __webpack_require__(1358);
var Menu_default = /*#__PURE__*/__webpack_require__.n(Menu_);
// EXTERNAL MODULE: external "@material-ui/icons/Facebook"
var Facebook_ = __webpack_require__(2089);
var Facebook_default = /*#__PURE__*/__webpack_require__.n(Facebook_);
// EXTERNAL MODULE: external "@material-ui/icons/Twitter"
var Twitter_ = __webpack_require__(4233);
var Twitter_default = /*#__PURE__*/__webpack_require__.n(Twitter_);
// EXTERNAL MODULE: external "@material-ui/icons/YouTube"
var YouTube_ = __webpack_require__(7764);
// EXTERNAL MODULE: external "@material-ui/icons/Instagram"
var Instagram_ = __webpack_require__(8162);
var Instagram_default = /*#__PURE__*/__webpack_require__.n(Instagram_);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/head/headv1.js












const HeadV1 = ({
  pos,
  open,
  setOpen
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: pos === "top" ? headv1_module.main : headv1_module.off,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: pos === "top" ? headv1_module.navbar : headv1_module.navbarFixed,
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: pos === "top" ? headv1_module.navbar1 : headv1_module.navbar1Fixed,
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/",
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/Logo/LogoWhite.png",
            className: headv1_module.logo,
            alt: "logo",
            onMouseLeave: e => {
              e.target.src = "/Logo/LogoWhite.png";
            },
            onMouseOver: e => {
              e.target.src = "/Logo/LogoDark.png";
            }
          })
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: pos === "top" ? headv1_module.navbar2 : headv1_module.navbar2Fixed,
        children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/info/about",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: headv1_module.buttonBox,
            children: /*#__PURE__*/jsx_runtime_.jsx("h4", {
              className: headv1_module.buttonFont,
              children: "About Ernie"
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/info/program",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: headv1_module.buttonBox,
            children: /*#__PURE__*/jsx_runtime_.jsx("h4", {
              className: headv1_module.buttonFont,
              children: "Platform"
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/blog",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: headv1_module.buttonBox,
            children: /*#__PURE__*/jsx_runtime_.jsx("h4", {
              className: headv1_module.buttonFont,
              children: "News"
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "https://docs.google.com/forms/d/1yoGOHrJUBUwfuhIeJDm18CGscvCLmGPlN-yno1-tQ-I/viewform?fbclid=IwAR3H0zii6wp9ukTk1OIWkntS8IbBySy2Mab2J0qjphUfefSKqWdDate7uuM&edit_requested=true",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: headv1_module.buttonBox,
            children: /*#__PURE__*/jsx_runtime_.jsx("h4", {
              className: headv1_module.buttonFont,
              children: "Get Involved"
            })
          })
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: headv1_module.navbar4,
        onClick: () => {
          setOpen(!open);
        },
        children: /*#__PURE__*/jsx_runtime_.jsx((Menu_default()), {
          style: {
            color: '#fff',
            fontSize: '40px',
            cursor: 'pointer'
          }
        })
      })]
    })
  });
};

/* harmony default export */ const headv1 = (HeadV1);
// EXTERNAL MODULE: ./styles/navigation/floater.module.css
var floater_module = __webpack_require__(5452);
// EXTERNAL MODULE: external "@material-ui/icons/Close"
var Close_ = __webpack_require__(8777);
var Close_default = /*#__PURE__*/__webpack_require__.n(Close_);
;// CONCATENATED MODULE: ./components/navigation/floater.js










function setCookie(cname, cvalue, exdays) {
  const d = new Date();
  d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000);
  let expires = "expires=" + d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
  let name = cname + "=";
  let decodedCookie = decodeURIComponent(document.cookie);
  let ca = decodedCookie.split(';');

  for (let i = 0; i < ca.length; i++) {
    let c = ca[i];

    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }

    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }

  return ca;
}

const Floater = ({
  backdrop = false
}) => {
  const [auth, setAuth] = external_react_.useState(false);

  function checkCookie() {
    let cookie = getCookie("cookie_authorized");
    console.log(cookie);

    if (cookie == 0) {
      setAuth(false);
    } else {
      setAuth(true);
    }
  }

  external_react_.useEffect(() => {
    checkCookie();
  }, []);

  function acceptCookie() {
    setCookie("cookie_authorized", "USER_ACCEPTED", 3);
    setAuth(true);
  }

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: floater_module.main,
    children: auth ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: floater_module.auth,
      children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
        className: !backdrop ? floater_module.text1 : floater_module.offText,
        children: "BAGONG PILIPINO "
      }), /*#__PURE__*/jsx_runtime_.jsx("h3", {
        className: !backdrop ? floater_module.text2 : floater_module.offText,
        children: "="
      }), /*#__PURE__*/jsx_runtime_.jsx("h3", {
        className: !backdrop ? floater_module.text1 : floater_module.offText,
        children: "BAGONG PILIPINAS"
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: floater_module.socialMediaContainer,
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: floater_module.socialBox,
          children: /*#__PURE__*/jsx_runtime_.jsx((Facebook_default()), {
            style: {
              color: "#000",
              fontSize: '20px'
            }
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: floater_module.socialBox,
          children: /*#__PURE__*/jsx_runtime_.jsx((Instagram_default()), {
            style: {
              color: "#000",
              fontSize: '20px'
            }
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: floater_module.socialBox,
          children: /*#__PURE__*/jsx_runtime_.jsx((Twitter_default()), {
            style: {
              color: "#000",
              fontSize: '20px'
            }
          })
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("h3", {
        className: floater_module.donateButton,
        children: "DONATE"
      })]
    }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: floater_module.off,
      children: [/*#__PURE__*/jsx_runtime_.jsx("h6", {
        className: floater_module.cookieText,
        children: "ernieabella.com uses cookies to give you a better navigation experience on our site. As soon as you continue the tour, we assume you accept the cookies policy. Learn more about the cookie policy we use here."
      }), /*#__PURE__*/jsx_runtime_.jsx("h6", {
        className: floater_module.cookieButton,
        onClick: acceptCookie,
        children: "I ACCEPT"
      }), /*#__PURE__*/jsx_runtime_.jsx((Close_default()), {
        style: {
          color: "#fff",
          fontSize: '30px',
          cursor: "pointer"
        },
        onClick: () => {
          setAuth(true);
        }
      })]
    })
  });
};

/* harmony default export */ const floater = (Floater);
;// CONCATENATED MODULE: ./components/head/headv2.js
/* eslint-disable @next/next/link-passhref */









function HeadV2({
  backdrop = false
}) {
  const [pos, setPos] = external_react_default().useState("top");
  const [open, setOpen] = external_react_default().useState("top");
  external_react_default().useEffect(() => {
    document.addEventListener("scroll", e => {
      let scrolled = document.scrollingElement.scrollTop;

      if (scrolled >= 10) {
        setPos("moved");
      } else {
        setPos("top");
      }
    });
  }, []);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: headv2_module.main,
    children: [/*#__PURE__*/jsx_runtime_.jsx(headv1, {
      pos: pos,
      open: open,
      setOpen: setOpen
    }), /*#__PURE__*/jsx_runtime_.jsx(navigationv1/* default */.Z, {
      header: true,
      pos: pos,
      open: open,
      setOpen: setOpen
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: backdrop && headv2_module.backdrop
    }), /*#__PURE__*/jsx_runtime_.jsx(floater, {
      backdrop: backdrop
    })]
  });
}

/***/ }),

/***/ 5452:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "floater_main__u84vR",
	"auth": "floater_auth__11ES6",
	"appear": "floater_appear__82EEC",
	"text1": "floater_text1__ZLljs",
	"text2": "floater_text2__1XKG2",
	"offText": "floater_offText__3UGhd",
	"socialMediaContainer": "floater_socialMediaContainer__2rR_y",
	"socialBox": "floater_socialBox__2tOcP",
	"donateButton": "floater_donateButton__YfNBd",
	"off": "floater_off__11R0R",
	"cookieText": "floater_cookieText__1xYel",
	"cookieButton": "floater_cookieButton__3PBS2"
};


/***/ }),

/***/ 1732:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "headv1_main__2kjmW",
	"off": "headv1_off__2sj2T",
	"navbar": "headv1_navbar__3vu-p",
	"navbarFixed": "headv1_navbarFixed__JfsXo",
	"logo": "headv1_logo__2LS0A",
	"navbar1": "headv1_navbar1__M26c0",
	"navbar1Fixed": "headv1_navbar1Fixed__1_Hjf",
	"navbar2": "headv1_navbar2__lLfAP",
	"navbar2Fixed": "headv1_navbar2Fixed__2uAYl",
	"navbar3": "headv1_navbar3__1QO74",
	"navbar4": "headv1_navbar4__F5LMW",
	"buttonFont": "headv1_buttonFont__NhoMz",
	"buttonFontSpecial": "headv1_buttonFontSpecial__39bW4",
	"buttonContainer": "headv1_buttonContainer__22qBU",
	"buttonBox": "headv1_buttonBox__1FGH_",
	"buttonBoxSpecial": "headv1_buttonBoxSpecial__lfkYc",
	"menuIcon": "headv1_menuIcon__2dew6",
	"optionOpen": "headv1_optionOpen__2TFKn",
	"openOption": "headv1_openOption__Qx0ew",
	"optionClose": "headv1_optionClose__3UheV",
	"socialMediaContainer": "headv1_socialMediaContainer__3-3-X",
	"socialBox": "headv1_socialBox__1_G-9",
	"donationBox": "headv1_donationBox__2IOgF",
	"logoTitle1": "headv1_logoTitle1__--PdN",
	"logoTitle2": "headv1_logoTitle2__2i4M7",
	"logoTitle3": "headv1_logoTitle3__2zj2N",
	"tinylogoToken": "headv1_tinylogoToken__3CNYT",
	"h4animate": "headv1_h4animate__tiGiJ"
};


/***/ }),

/***/ 1011:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "headv2_main__2kQze",
	"backdrop": "headv2_backdrop__lD24X",
	"startup": "headv2_startup__3Zltb"
};


/***/ })

};
;