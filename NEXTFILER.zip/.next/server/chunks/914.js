exports.id = 914;
exports.ids = [914];
exports.modules = {

/***/ 4656:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(701);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9886);
/* harmony import */ var _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);






const FooterV2 = () => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
    className: _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_4__.foooterv2,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
      className: _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_4__.copywrite,
      children: "2021 Copyright \xA9 ERNESTO ABELLA for PH. All Rights Reserved."
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FooterV2);

/***/ }),

/***/ 5000:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(701);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_newsection_newsection1_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7604);
/* harmony import */ var _styles_newsection_newsection1_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_newsection_newsection1_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);







const NewSection1 = () => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
    className: _styles_newsection_newsection1_module_css__WEBPACK_IMPORTED_MODULE_4__.main,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
      className: _styles_newsection_newsection1_module_css__WEBPACK_IMPORTED_MODULE_4__.mainContainer,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h2", {
        className: _styles_newsection_newsection1_module_css__WEBPACK_IMPORTED_MODULE_4__.mainTitle,
        children: "De nouvelles r\xE8gles pour voyager vers la France entrent en vigueur ce samedi"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("img", {
        className: _styles_newsection_newsection1_module_css__WEBPACK_IMPORTED_MODULE_4__.mainImage,
        src: "/Thumbnail/ernieabella.png"
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
      className: _styles_newsection_newsection1_module_css__WEBPACK_IMPORTED_MODULE_4__.subContainer,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h5", {
        className: _styles_newsection_newsection1_module_css__WEBPACK_IMPORTED_MODULE_4__.label,
        children: "FEATURING"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h4", {
        className: _styles_newsection_newsection1_module_css__WEBPACK_IMPORTED_MODULE_4__.subTitle,
        children: "De nouvelles r\xE8gles pour voyager vers la France entrent en vigueur ce samedi"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h4", {
        className: _styles_newsection_newsection1_module_css__WEBPACK_IMPORTED_MODULE_4__.subTitle,
        children: "De nouvelles r\xE8gles pour voyager vers la France entrent en vigueur ce samedi"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("h4", {
        className: _styles_newsection_newsection1_module_css__WEBPACK_IMPORTED_MODULE_4__.subTitle,
        children: "De nouvelles r\xE8gles pour voyager vers la France entrent en vigueur ce samedi"
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NewSection1);

/***/ }),

/***/ 7604:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "newsection1_main__1B4vE",
	"mainContainer": "newsection1_mainContainer__2Uuc3",
	"mainTitle": "newsection1_mainTitle__3dscg",
	"mainImage": "newsection1_mainImage__2L9wp",
	"subContainer": "newsection1_subContainer__2nxid",
	"label": "newsection1_label__2vBw7",
	"subTitle": "newsection1_subTitle__1v8su"
};


/***/ }),

/***/ 2044:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"L":"https://bagongbayan.herokuapp.com"}');

/***/ })

};
;