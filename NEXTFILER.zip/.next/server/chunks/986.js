exports.id = 986;
exports.ids = [986];
exports.modules = {

/***/ 7047:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(701);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7917);
/* harmony import */ var _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var _material_ui_icons_FiberManualRecord__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2987);
/* harmony import */ var _material_ui_icons_FiberManualRecord__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_FiberManualRecord__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);







const bio = ["A FOUNDATIONAL Builder.", "A Father to 2 Children, Immanuel Romualdo Lao Abella and Lia Luisa Abella-Hutchinson and a Husband  of 1 wife, Married to Joy Lao Abella", "18 Years as a Church Minister (Founder, and Pastor, The Jesus Fellowship, DAVAO) ", "He started from 10-15 youth group, which grew into thousands of members each event/ service."];
const government = ["Former DFA Undersecretary for Strategic Communications on 2017 until 2021 October.", "The First and former Spokesperson of President Rodrigo Roa Duterte in 2016", "Officer-in-charge of UNESCO National Commission"];
const business = ["A SOCIAL ENTREPRENEUR for 19 years.", "A Leader who works with the CIVIL SOCIETY from 1988 until Present.", "A FOUNDATIONAL Builder.", "A Father figure to Many.", "20 Years as an Educator - Founder, and Former President of The Southpoint School, Davao", "20 Years in Cooperative Founder, and Former Chairman of One Accord Cooperative, Davao - this coop started from 10,000 pesos now , Millions in Assets, has helped a multitude of Start-Ups from Davao to Luzon and Visayas"];
const academic = ["Masters in Entrepreneurship at Asian Institute of Management (AIM) - Social Entrepreneurship.", "Masters of Divinity at Siliman University - Cumlaude", "Studied Communication Arts at the Ateneo de Manila Graduate School", "Graduated, AB Pre-Med at the Ateneo de Davao"];

const AboutSection1 = () => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
    className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.main,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
      className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.container,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
        className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.imageBox,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("img", {
          src: "/Images/papaImage2.png",
          className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.image
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
        className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.contentBox,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("h6", {
          className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.title,
          children: "ABOUT"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
          className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.underline
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
          className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.textBox,
          children: "Ernesto \"Ernie\" Corpuz Abella is a Filipino businessman, writer, and former evangelist who served in President Rodrigo Duterte's administration as Presidential Spokesperson (2016-2017) and Undersecretary for Strategic Communications and Research of the Department of Foreign Affairs (2017-2021)."
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
          className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.textBox,
          children: "Before joining the government, he was an executive with a Davao city-based agricultural products manufacturer and a local cooperative which he co-founded. He also established a school in Davao and was a columnist for local newspaper Sunstar Davao."
        })]
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
      className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.container2,
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
        className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.contentBox2,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("h6", {
          className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.title,
          children: "BIO"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
          className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.underline2
        }), bio.map((data, index) => {
          return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
            className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.textContainer,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((_material_ui_icons_FiberManualRecord__WEBPACK_IMPORTED_MODULE_3___default()), {
              style: {
                color: '#fff'
              }
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("p", {
              className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.textItem,
              children: data
            })]
          }, index);
        })]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
      className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.container2,
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
        className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.contentBox2,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("h6", {
          className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.title,
          children: "Background in Governance"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
          className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.underline2
        }), government.map((data, index) => {
          return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
            className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.textContainer,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((_material_ui_icons_FiberManualRecord__WEBPACK_IMPORTED_MODULE_3___default()), {
              style: {
                color: '#fff'
              }
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("p", {
              className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.textItem,
              children: data
            })]
          }, index);
        })]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
      className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.container2,
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
        className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.contentBox2,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("h6", {
          className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.title,
          children: "Business Experience"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
          className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.underline2
        }), business.map((data, index) => {
          return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
            className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.textContainer,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((_material_ui_icons_FiberManualRecord__WEBPACK_IMPORTED_MODULE_3___default()), {
              style: {
                color: '#fff'
              }
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("p", {
              className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.textItem,
              children: data
            })]
          }, index);
        })]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
      className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.container2,
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
        className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.contentBox2,
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("h6", {
          className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.title,
          children: "ACADEMIC EXPERIENCE"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
          className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.underline2
        }), academic.map((data, index) => {
          return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
            className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.textContainer,
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx((_material_ui_icons_FiberManualRecord__WEBPACK_IMPORTED_MODULE_3___default()), {
              style: {
                color: '#fff'
              }
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("p", {
              className: _styles_aboutsection_aboutsection1_module_css__WEBPACK_IMPORTED_MODULE_5__.textItem,
              children: data
            })]
          }, index);
        })]
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AboutSection1);

/***/ }),

/***/ 4656:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(701);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9886);
/* harmony import */ var _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);






const FooterV2 = () => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
    className: _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_4__.foooterv2,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
      className: _styles_navigation_footerv1_module_css__WEBPACK_IMPORTED_MODULE_4__.copywrite,
      children: "2021 Copyright \xA9 ERNESTO ABELLA for PH. All Rights Reserved."
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FooterV2);

/***/ }),

/***/ 3365:
/***/ ((module) => {

// Exports
module.exports = {

};


/***/ }),

/***/ 7917:
/***/ ((module) => {

// Exports
module.exports = {
	"main": "aboutsection1_main__32qjg",
	"container": "aboutsection1_container__2qS3o",
	"container2": "aboutsection1_container2__2Y1Ix",
	"imageBox": "aboutsection1_imageBox__1YNbn",
	"image": "aboutsection1_image__3NafL",
	"contentBox": "aboutsection1_contentBox__37BM6",
	"contentBox2": "aboutsection1_contentBox2__15QV1",
	"title": "aboutsection1_title__n7vfo",
	"underline": "aboutsection1_underline__2GaQ_",
	"underline2": "aboutsection1_underline2__nIPq1",
	"textBox": "aboutsection1_textBox__2Pndq",
	"textContainer": "aboutsection1_textContainer__26e5S",
	"textItem": "aboutsection1_textItem__25odn"
};


/***/ })

};
;